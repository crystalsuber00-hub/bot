# Job bot setup (about 3 minutes)

You need Python 3.11 or newer.

```
cd jobbot
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e .
jobapply init
```

`jobapply init` asks for your name, email, phone, the job titles you want, your city,
the other cities you will commute to, whether remote is OK, your lowest hourly pay, and
your resume file. It writes `profile.toml` for you.

## Every day

```
jobapply search                      # remote jobs that match your titles
jobapply search -f my_jobs.json      # or import a list of jobs (JSON or CSV)
jobapply review --approve-above 1    # approve the matches
jobapply apply --no-email            # opens each job in your browser, you submit it
jobapply applied                     # everything you already applied to
```

- Nothing is ever sent without you pressing Enter on each job.
- `--no-email` means no email password is needed. To also email employers, set
  `SMTP_PASSWORD` to an app password (never your normal password) and leave off `--no-email`.
- Change wording, titles, cities or pay any time with `jobapply edit`.
- Jobs near you come from lists you import (JSON/CSV with title, company, location, url)
  or from an Adzuna account (free keys in ADZUNA_APP_ID and ADZUNA_APP_KEY, then add
  "adzuna" to `sources` in profile.toml). The built-in sources are remote jobs only.
