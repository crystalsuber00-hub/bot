from pathlib import Path
from jobapply import queue, sources
from jobapply.__main__ import main
from jobapply.profile import Profile

P = Profile(name="A", email="a@x.com", keywords=["payroll", "remote"], exclude=["clearance"], min_salary=50000)


def job(**kw):
    return sources._job("t", kw.get("title", "Payroll Specialist"), "Co", kw.get("url", "u"),
                        description=kw.get("description", ""), salary=kw.get("salary", 0))


def test_score_and_filters():
    assert sources.score(job(description="remote work"), P) == 2
    assert sources.score(job(description="needs clearance"), P) == -1
    assert sources.score(job(salary=40000), P) == -1


def test_merge_dedupes():
    jobs = {}
    assert queue.merge(jobs, [job(), job()]) == 1


def test_cli_flow(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text('[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\n')
    (tmp_path / "l.json").write_text('[{"title":"Payroll Specialist","company":"Co","url":"http://j/1"}]')
    monkeypatch.setattr(sources, "SOURCES", {})
    main(["search", "-f", "l.json"])
    main(["review", "--approve-above", "1"])
    main(["apply", "--dry-run"])
    assert "Payroll Specialist" in capsys.readouterr().out
    assert queue.load()


def test_intro_and_cap(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text('[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\ndaily_limit=1\ndelay_seconds=0\n')
    (tmp_path / "l.csv").write_text("title,company,url,email,contact\nPayroll Specialist,Co,http://j/1,jobs@co.com,hr@co.com\n"
                                    "Payroll Specialist,Co2,http://j/2,jobs@co2.com,hr@co2.com\n")
    monkeypatch.setattr(sources, "SOURCES", {})
    main(["search", "-f", "l.csv"])
    main(["review", "--approve-above", "1"])
    main(["apply", "--dry-run"])
    assert "[intro email to hr@co.com]" in capsys.readouterr().out
    sent = []
    from jobapply import __main__ as m
    monkeypatch.setattr(m, "send_email", lambda j, p, l, to="", subject="": sent.append(to or j["email"]))
    main(["apply"])
    assert sent == ["jobs@co.com", "hr@co.com"]  # cap of 1 application (+its intro)


def test_preview_uses_headline_and_bullets(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text(
        '[profile]\nname="A"\nemail="a@x.com"\nphone="1"\nheadline="I am great."\n'
        'highlights=["Did X","Did Y"]\n')
    main(["preview"])
    out = capsys.readouterr().out
    assert "- Did X\n- Did Y" in out and "I am great." in out
    assert "Subject: Application: Payroll Specialist - A" in out
    assert "Subject: Introduction:" in out
    assert "\n\n\n" not in out


def test_no_highlights_falls_back_to_summary(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text('[profile]\nname="A"\nemail="a@x.com"\nsummary="Old summary."\n')
    main(["preview"])
    assert "Old summary." in capsys.readouterr().out


def test_failed_intro_does_not_crash_and_is_retried(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text('[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\ndelay_seconds=0\n')
    (tmp_path / "l.csv").write_text("title,company,url,email,contact\nPayroll Specialist,Co,http://j/1,jobs@co.com,hr@co.com\n")
    monkeypatch.setattr(sources, "SOURCES", {})
    main(["search", "-f", "l.csv"])
    main(["review", "--approve-above", "1"])
    from jobapply import __main__ as m
    def boom(j, p, l, to="", subject=""):
        if to:
            raise RuntimeError("bad password")
    monkeypatch.setattr(m, "send_email", boom)
    main(["apply"])  # application ok, intro fails -> must not raise
    job = next(iter(queue.load().values()))
    assert job["status"] == "applied" and not job.get("intro_sent")
    sent = []
    monkeypatch.setattr(m, "send_email", lambda j, p, l, to="", subject="": sent.append(to))
    main(["apply"])  # retry
    assert sent == ["hr@co.com"] and next(iter(queue.load().values()))["intro_sent"]


def test_contacts_file_fills_intro_and_watch_only_alerts(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text('[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\nsources=[]\n')
    (tmp_path / "contacts.csv").write_text("company,email\nFormco,hr@f.com\n")
    (tmp_path / "inbox").mkdir()
    (tmp_path / "inbox" / "l.csv").write_text("title,company,url,email,contact\nPayroll Clerk,Formco,http://j/2,,\n")
    from jobapply import __main__ as m
    alerts, sent = [], []
    monkeypatch.setattr(m, "alert", lambda t, b="": alerts.append(t))
    monkeypatch.setattr(m, "send_email", lambda *a, **k: sent.append(1))
    main(["watch", "--once"])
    job = next(iter(queue.load().values()))
    assert job["contact"] == "hr@f.com" and job["status"] == "new"   # not approved, not sent
    assert len(alerts) == 1 and sent == []
    main(["watch", "--once"])
    assert len(alerts) == 1                                        # no repeat alert


def test_rescore_reopens_location_rejects(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    prof = '[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\nsources=[]\nlocations=["Oakland"]\n'
    (tmp_path / "profile.toml").write_text(prof)
    (tmp_path / "l.csv").write_text("title,company,url,location\nPayroll Clerk,Co,http://j/1,\"Los Gatos, CA\"\n")
    main(["search", "-f", "l.csv"])
    assert next(iter(queue.load().values()))["status"] == "rejected"
    (tmp_path / "profile.toml").write_text(prof.replace('["Oakland"]', '["Oakland", "Los Gatos"]'))
    main(["review", "--rescore", "--approve-above", "1"])
    assert next(iter(queue.load().values()))["status"] == "approved"


def test_headlines_rotate_per_job_but_stay_stable():
    from jobapply.apply import cover_letter
    p = Profile(name="A", email="a@x.com", headlines=["H0.", "H1.", "H2."])
    jobs = [sources._job("t", "Payroll Clerk", "Co", f"http://j/{i}") for i in range(12)]
    used = {next(h for h in p.headlines if h in cover_letter(j, p)) for j in jobs}
    assert len(used) > 1                                         # variety across jobs
    assert all(cover_letter(j, p) == cover_letter(j, p) for j in jobs)  # same job, same text


def test_cover_letter_cap_makes_the_rest_resume_only(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text(
        '[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\nsources=[]\ncover_letters_per_day=2\n')
    rows = "".join(f"Payroll Clerk,Co{i},http://j/{i}\n" for i in range(4))
    (tmp_path / "l.csv").write_text("title,company,url\n" + rows)
    from jobapply import __main__ as m
    copied = []
    monkeypatch.setattr(m, "open_manual", lambda j, l, d, copy=True: copied.append(copy) or Path("x"))
    monkeypatch.setattr("builtins.input", lambda *_: "")
    main(["search", "-f", "l.csv"])
    main(["review", "--approve-above", "1"])
    main(["apply"])
    assert copied == [True, True, False, False]
    assert "resume only" in capsys.readouterr().out


def test_accounts_payable_titles_are_accepted_and_scored():
    p = Profile(name="A", email="a@x.com", keywords=["payroll"])
    j = sources._job("t", "Accounts Payable Specialist", "Co", "u")
    assert sources.score(j, p) >= 1
    assert sources.score(sources._job("t", "Office Manager", "Co", "u2"), p) == -1


def test_force_skips_filters_but_normal_jobs_do_not():
    p = Profile(name="A", email="a@x.com", keywords=["payroll"], exclude=["senior payroll", "ai trainer"],
                locations=["Oakland"])
    plain = sources._job("t", "Senior Payroll Analyst", "Co", "u1", "Remote")
    forced = sources._job("t", "Senior Payroll Analyst", "Co", "u2", "Remote", force=True)
    assert sources.score(plain, p) == -1
    assert sources.score(forced, p) >= 1


def test_force_column_in_json_import(tmp_path):
    f = tmp_path / "l.json"
    f.write_text('[{"title":"Payroll Manager","company":"C","url":"http://x","force":true}]')
    assert sources.from_file(str(f))[0]["force"] is True


def test_no_email_flag_opens_browser_and_sends_nothing(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text('[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\ndelay_seconds=0\nsources=[]\n')
    (tmp_path / "l.csv").write_text("title,company,url,email,contact\nPayroll Clerk,Co,http://j/1,jobs@co.com,hr@co.com\n")
    from jobapply import __main__ as m
    sent, opened = [], []
    monkeypatch.setattr(m, "send_email", lambda *a, **k: sent.append(1))
    monkeypatch.setattr(m, "open_manual", lambda j, l, d, copy=True: opened.append(j["company"]) or Path("x"))
    monkeypatch.setattr("builtins.input", lambda *_: "")
    main(["search", "-f", "l.csv"])
    main(["review", "--approve-above", "1"])
    main(["apply", "--no-email"])
    assert sent == [] and opened == ["Co"]
    assert next(iter(queue.load().values()))["status"] == "applied"


def test_skip_letter_imports_and_stays_resume_only(tmp_path, monkeypatch, capsys):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "profile.toml").write_text('[profile]\nname="A"\nemail="a@x.com"\nkeywords=["payroll"]\nsources=[]\ndelay_seconds=0\n')
    (tmp_path / "l.json").write_text(
        '[{"title":"Phlebotomist","company":"Lab","url":"http://x","force":true,"skip_letter":true}]')
    from jobapply import __main__ as m
    copied = []
    monkeypatch.setattr(m, "open_manual", lambda j, l, d, copy=True: copied.append(copy) or Path("x"))
    monkeypatch.setattr("builtins.input", lambda *_: "")
    main(["search", "-f", "l.json"])
    main(["review", "--approve-above", "1"])
    main(["apply", "--no-email"])
    assert copied == [False]
    assert "doesn't fit this job" in capsys.readouterr().out


def test_merge_skips_job_already_applied_under_another_link():
    from jobapply import queue
    jobs = {"a": {"id": "a", "company": "Acme", "title": "Scheduler", "status": "applied"}}
    found = [{"id": "b", "company": "ACME", "title": "scheduler", "status": "new"}]
    queue.merge(jobs, found)
    assert jobs["b"]["status"] == "skipped"


def test_init_writes_a_loadable_profile(tmp_path, monkeypatch):
    import builtins
    from jobapply import __main__ as m
    from jobapply.profile import load_profile
    answers = iter(["Pat Lee", "pat@example.com", "555-1", "medical receptionist, scheduler",
                    "Oakland", "ca", "Berkeley, Alameda", "y", "26", "me.pdf"])
    monkeypatch.setattr(builtins, "input", lambda *_: next(answers))
    cfg = tmp_path / "profile.toml"
    m.main(["-c", str(cfg), "init"])
    p = load_profile(cfg)
    assert p.name == "Pat Lee" and p.title_keywords == ["medical receptionist", "scheduler"]
    assert p.locations == ["Oakland", "Berkeley", "Alameda", "Remote"]
    assert p.search_locations[0] == "Oakland, CA" and p.min_salary == 26 * 2080
